# Ai Resume Builder

Create professional resumes using AI.

## Setup
1. Install dependencies
2. Run with Flask
